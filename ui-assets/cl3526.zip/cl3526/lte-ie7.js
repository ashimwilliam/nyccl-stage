/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'cl\'">' + entity + '</span>' + html;
	}
	var icons = {
			'ico-cal' : '&#x22;',
			'ico-thumb' : '&#x23;',
			'ico-plane' : '&#x24;',
			'ico-plus' : '&#x31;',
			'ico-search-alt' : '&#x32;',
			'ico-minus' : '&#x33;',
			'ico-up' : '&#x34;',
			'ico-right' : '&#x35;',
			'ico-down' : '&#x36;',
			'ico-left' : '&#x37;',
			'ico-mail' : '&#x38;',
			'ico-edit' : '&#x39;',
			'ico-ok' : '&#x61;',
			'ico-cancel' : '&#x62;',
			'ico-forward' : '&#x63;',
			'ico-chat' : '&#x64;',
			'ico-location' : '&#x65;',
			'ico-menu' : '&#x66;',
			'ico-video' : '&#x67;',
			'ico-globe' : '&#x68;',
			'ico-user' : '&#x69;',
			'ico-doc' : '&#x6a;',
			'ico-search' : '&#x6b;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/ico-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};